# object-detection > 2023-09-18 1:13pm
https://universe.roboflow.com/youssef-mohamed-dylvh/object-detection-0wrzz

Provided by a Roboflow user
License: CC BY 4.0

