# shape detector > 2023-09-15 12:10pm
https://universe.roboflow.com/youssef-mohamed-dylvh/shape-detector-gbqpp

Provided by a Roboflow user
License: CC BY 4.0

